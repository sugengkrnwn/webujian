
<?php

session_destroy();

?>
<script language="javascript">document.location.href='indexa.php'</script>